"""Small SQLite layer. Structured fields are stored as JSON text."""
import json
import sqlite3
import threading
import time
import uuid

from .config import DATA_DIR

_DB_PATH = DATA_DIR / "talentlens.db"
_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    requirements TEXT NOT NULL,
    min_years REAL DEFAULT 0,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS candidates (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    name TEXT,
    raw_text TEXT,
    status TEXT DEFAULT 'processing',
    decision TEXT DEFAULT 'none',
    score REAL,
    scores TEXT,
    analysis TEXT,
    error TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cand_job ON candidates(job_id);
"""


def _conn():
    conn = sqlite3.connect(_DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init():
    with _lock, _conn() as c:
        c.executescript(SCHEMA)


def new_id() -> str:
    return uuid.uuid4().hex[:12]


def execute(sql: str, params: tuple = ()):
    with _lock, _conn() as c:
        c.execute(sql, params)


def query(sql: str, params: tuple = ()) -> list[dict]:
    with _lock, _conn() as c:
        return [dict(r) for r in c.execute(sql, params).fetchall()]


def one(sql: str, params: tuple = ()) -> dict | None:
    rows = query(sql, params)
    return rows[0] if rows else None


def jdump(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)


def jload(text, default=None):
    if not text:
        return default
    try:
        return json.loads(text)
    except Exception:
        return default


def now() -> float:
    return time.time()
