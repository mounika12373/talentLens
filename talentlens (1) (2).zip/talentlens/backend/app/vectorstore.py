"""ChromaDB wrapper. One persistent collection; chunks are tagged with job and candidate ids."""
import hashlib
import math
import re
import threading

import chromadb

from . import config

_client = chromadb.PersistentClient(path=str(config.DATA_DIR / "chroma"))
_collection = _client.get_or_create_collection("resume_chunks", metadata={"hnsw:space": "cosine"})
_embed_lock = threading.Lock()
_default_fn = None


def _hash_embed(texts: list[str], dim: int = 384) -> list[list[float]]:
    """Offline bag-of-words embedding. Only for tests; real runs use MiniLM."""
    out = []
    for t in texts:
        v = [0.0] * dim
        for tok in re.findall(r"[a-z0-9+#.]+", t.lower()):
            h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
            v[h % dim] += 1.0
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        out.append([x / n for x in v])
    return out


def embed(texts: list[str]) -> list[list[float]]:
    global _default_fn
    if config.EMBEDDINGS == "hash":
        return _hash_embed(texts)
    with _embed_lock:
        if _default_fn is None:
            from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

            _default_fn = DefaultEmbeddingFunction()
        return [list(map(float, v)) for v in _default_fn(texts)]


def add_chunks(job_id: str, candidate_id: str, chunks: list[dict]):
    if not chunks:
        return
    texts = [c["text"] for c in chunks]
    _collection.add(
        ids=[f"{candidate_id}:{i}" for i in range(len(chunks))],
        documents=texts,
        embeddings=embed(texts),
        metadatas=[
            {"job_id": job_id, "candidate_id": candidate_id, "section": c["section"], "idx": i}
            for i, c in enumerate(chunks)
        ],
    )


def search(query: str, where: dict, k: int = 3) -> list[dict]:
    """Return top-k chunks with similarity in [0, 1] (1 = identical)."""
    try:
        res = _collection.query(query_embeddings=embed([query]), n_results=k, where=where)
    except Exception:
        return []
    hits = []
    for doc, meta, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0]):
        hits.append(
            {
                "text": doc,
                "section": meta.get("section", "general"),
                "candidate_id": meta.get("candidate_id"),
                "similarity": max(0.0, min(1.0, 1.0 - float(dist))),
            }
        )
    return hits


def delete_candidate(candidate_id: str):
    _collection.delete(where={"candidate_id": candidate_id})


def delete_job(job_id: str):
    _collection.delete(where={"job_id": job_id})
