"""Rule-based fallbacks. Used when no Grok key is set or an API call fails, so the app always works."""
import re

# canonical skill -> aliases (all matched with word boundaries, case-insensitive)
SKILLS: dict[str, list[str]] = {
    "Python": ["python"], "Java": ["java"], "JavaScript": ["javascript", "js", "ecmascript"],
    "TypeScript": ["typescript"], "C++": ["c\\+\\+"], "C#": ["c#"], "Go": ["golang", "go lang"],
    "Rust": ["rust"], "SQL": ["sql", "postgresql", "mysql", "postgres", "sql server"],
    "NoSQL": ["nosql", "mongodb", "cassandra", "dynamodb"], "R": ["r programming", "rstudio"],
    "Machine Learning": ["machine learning", "ml"], "Deep Learning": ["deep learning"],
    "NLP": ["nlp", "natural language processing", "text mining"],
    "Computer Vision": ["computer vision", "image recognition", "opencv"],
    "PyTorch": ["pytorch", "torch"], "TensorFlow": ["tensorflow", "keras"],
    "scikit-learn": ["scikit-learn", "sklearn", "scikit learn"],
    "Pandas": ["pandas"], "NumPy": ["numpy"], "Statistics": ["statistics", "statistical", "hypothesis testing"],
    "Transformers": ["transformers", "bert", "gpt", "hugging face", "huggingface"],
    "LLMs": ["llm", "llms", "large language model", "large language models", "generative ai", "genai"],
    "RAG": ["rag", "retrieval augmented generation", "retrieval-augmented generation"],
    "Vector Databases": ["vector database", "vector databases", "chroma", "chromadb", "pinecone", "faiss", "weaviate", "milvus", "pgvector"],
    "LangChain": ["langchain", "llamaindex", "llama index"],
    "Prompt Engineering": ["prompt engineering", "prompt design"],
    "MLOps": ["mlops", "mlflow", "kubeflow", "model deployment", "model serving"],
    "Data Engineering": ["data engineering", "etl", "elt", "data pipelines", "data pipeline", "pipelines", "airflow"],
    "Spark": ["spark", "pyspark", "databricks"], "Airflow": ["airflow"], "Kafka": ["kafka"],
    "Snowflake": ["snowflake"], "dbt": ["dbt"],
    "AWS": ["aws", "amazon web services", "sagemaker", "lambda", "s3", "ec2"],
    "Azure": ["azure"], "GCP": ["gcp", "google cloud", "vertex ai", "bigquery"],
    "Docker": ["docker", "containers", "containerization"], "Kubernetes": ["kubernetes", "k8s"],
    "CI/CD": ["ci/cd", "cicd", "jenkins", "github actions", "gitlab ci"],
    "Git": ["git", "github", "gitlab"], "Linux": ["linux", "unix", "bash"],
    "REST APIs": ["rest", "restful", "rest api", "rest apis", "apis", "api", "fastapi", "flask", "django"], "GraphQL": ["graphql"],
    "FastAPI": ["fastapi"], "Flask": ["flask"], "Django": ["django"], "Node.js": ["node.js", "nodejs", "node"],
    "React": ["react", "react.js", "reactjs"], "Next.js": ["next.js", "nextjs"], "Angular": ["angular"],
    "Vue": ["vue", "vue.js"], "HTML/CSS": ["html", "css", "html5", "css3"], "Tailwind CSS": ["tailwind", "tailwindcss"],
    "Redux": ["redux"], "Tableau": ["tableau"], "Power BI": ["power bi", "powerbi"],
    "Data Visualization": ["data visualization", "data visualisation", "matplotlib", "seaborn", "plotly"],
    "Excel": ["excel", "advanced excel"], "A/B Testing": ["a/b testing", "ab testing", "experimentation"],
    "Jupyter": ["jupyter", "notebooks"], "Agile": ["agile", "scrum", "kanban"],
    "Testing": ["unit testing", "pytest", "jest", "test automation", "selenium"],
    "Microservices": ["microservices", "microservice"], "System Design": ["system design", "distributed systems"],
    "Terraform": ["terraform", "infrastructure as code", "iac"],
    "Security": ["cybersecurity", "application security", "owasp"],
    "Communication": ["communication", "stakeholder management"], "Leadership": ["leadership", "mentoring", "team lead"],
    "Project Management": ["project management", "pmp", "jira"],
}

_COMPILED = {
    skill: re.compile(r"(?<![A-Za-z0-9+#])(?:" + "|".join(a if "\\" in a else re.escape(a) for a in aliases) + r")(?![A-Za-z0-9+#])", re.I)
    for skill, aliases in SKILLS.items()
}

NICE_MARKERS = re.compile(r"(nice to have|good to have|preferred|bonus|plus|desirable|optional)", re.I)


def find_skills(text: str) -> list[str]:
    return [s for s, rx in _COMPILED.items() if rx.search(text)]


def has_skill(text: str, skill: str) -> bool:
    rx = _COMPILED.get(skill)
    if rx is None:
        return bool(re.search(re.escape(skill), text, re.I))
    return bool(rx.search(text))


def extract_requirements(title: str, description: str) -> dict:
    """Skills named after a 'nice to have' style marker are nice-to-have; others are must-have."""
    split = NICE_MARKERS.search(description)
    must_text = description[: split.start()] if split else description
    nice_text = description[split.start():] if split else ""
    must = find_skills(title + "\n" + must_text)
    nice = [s for s in find_skills(nice_text) if s not in must]
    years = re.findall(r"(\d{1,2})\s*\+?\s*(?:years|yrs)", description, re.I)
    min_years = float(min(int(y) for y in years)) if years else 0.0
    return {
        "must": must,
        "nice": nice,
        "min_years": min_years,
        "seniority": "",
        "summary": "",
    }


YEARS_RX = re.compile(r"(\d{1,2}(?:\.\d)?)\s*\+?\s*(?:years|yrs|year)\b(?:\s+of)?(?:\s+\w+){0,3}?\s*(?:experience|exp)?", re.I)


def extract_years(text: str) -> float:
    """Largest plausible 'N years' mention (0.5 to 40)."""
    vals = [float(m.group(1)) for m in YEARS_RX.finditer(text)]
    vals = [v for v in vals if 0.5 <= v <= 40]
    return max(vals) if vals else 0.0


def guess_name(text: str, filename: str) -> str:
    for line in text.split("\n")[:6]:
        line = line.strip()
        if re.fullmatch(r"[A-Za-z][A-Za-z.'\- ]{2,40}", line) and 1 < len(line.split()) <= 4 and "@" not in line:
            return line.title() if line.isupper() else line
    stem = re.sub(r"\.[A-Za-z0-9]+$", "", filename)
    return re.sub(r"[_\-]+", " ", stem).strip().title() or "Unknown candidate"


def evidence_line(text: str, skill: str, limit: int = 220) -> str:
    """First resume line that actually mentions the skill (used as a quotable proof)."""
    for line in text.split("\n"):
        if has_skill(line, skill):
            return re.sub(r"^[\-\*\u2022\s]+", "", line).strip()[:limit]
    return ""


def guess_headline(text: str) -> str:
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    from .parsing import SECTION_WORDS
    for l in lines[1:5]:
        if "@" in l or len(l) < 4 or re.sub(r"[^a-z ]", "", l.lower()).strip() in SECTION_WORDS:
            continue
        return re.split(r"\s*\|\s*", l)[0][:90]
    return ""
