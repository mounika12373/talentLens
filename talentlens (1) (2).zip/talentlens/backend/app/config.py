"""Central settings, read from environment variables (or a .env file)."""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except Exception:  # python-dotenv is optional
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Grok (xAI) exposes an OpenAI-compatible API.
XAI_API_KEY = os.getenv("XAI_API_KEY", "").strip()
XAI_BASE_URL = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1")
XAI_MODEL = os.getenv("XAI_MODEL", "grok-4")

# "default" = Chroma's built-in MiniLM (ONNX) embeddings, downloaded once.
# "hash"    = tiny offline embeddings, only for tests and demos without internet.
EMBEDDINGS = os.getenv("EMBEDDINGS", "default").lower()

# Final score = 100 * (W_SKILLS * coverage + W_SEMANTIC * semantic + W_EXPERIENCE * experience)
W_SKILLS = float(os.getenv("W_SKILLS", 0.55))
W_SEMANTIC = float(os.getenv("W_SEMANTIC", 0.25))
W_EXPERIENCE = float(os.getenv("W_EXPERIENCE", 0.20))

MAX_UPLOAD_MB = 10
WORKERS = int(os.getenv("WORKERS", 4))
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(",")
