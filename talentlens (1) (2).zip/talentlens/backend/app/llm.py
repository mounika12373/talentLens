"""Grok (xAI) client. The API is OpenAI-compatible, so the openai SDK is used with a custom base_url."""
import json
import re

from . import config

_client = None


def available() -> bool:
    return bool(config.XAI_API_KEY)


def _get():
    global _client
    if _client is None:
        from openai import OpenAI

        _client = OpenAI(api_key=config.XAI_API_KEY, base_url=config.XAI_BASE_URL, timeout=90.0)
    return _client


def chat(system: str, user: str, *, json_mode: bool = False, temperature: float = 0.1, max_tokens: int = 1800) -> str:
    kwargs = dict(
        model=config.XAI_MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        temperature=temperature,
        max_tokens=max_tokens,
    )
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}
    resp = _get().chat.completions.create(**kwargs)
    return resp.choices[0].message.content or ""


def chat_json(system: str, user: str, **kw) -> dict:
    raw = chat(system, user + "\n\nReturn ONLY valid JSON.", json_mode=True, **kw)
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw, re.S)
        if m:
            return json.loads(m.group(0))
        raise
