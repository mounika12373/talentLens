"""TalentLens API. Run with:  uvicorn app.main:app --reload --port 8000"""
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from . import config, db, demo, llm, pipeline

db.init()
app = FastAPI(title="TalentLens API", version="1.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=config.CORS_ORIGINS, allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)
pool = ThreadPoolExecutor(max_workers=config.WORKERS)

ALLOWED = (".pdf", ".docx", ".txt", ".md")


class JobIn(BaseModel):
    title: str
    description: str


class AskIn(BaseModel):
    question: str


class DecisionIn(BaseModel):
    decision: str  # none | shortlist | maybe | reject


def _cand_out(c: dict, full: bool = False) -> dict:
    out = {
        "id": c["id"], "job_id": c["job_id"], "filename": c["filename"], "name": c["name"],
        "status": c["status"], "decision": c["decision"], "score": c["score"],
        "scores": db.jload(c["scores"]), "error": c["error"],
    }
    a = db.jload(c["analysis"])
    if a:
        out["headline"] = a.get("headline")
        out["recommendation"] = a.get("recommendation")
        out["years_experience"] = a.get("years_experience")
        out["missing_must"] = a.get("missing_must", [])
        out["engine"] = a.get("engine")
        out["matched"] = sum(1 for r in a["requirements"] if r["status"] == "strong")
        out["total_reqs"] = len(a["requirements"])
    if full:
        out["analysis"] = a
        out["resume_text"] = c["raw_text"]
    return out


@app.get("/api/health")
def health():
    return {"ok": True, "llm": "grok" if llm.available() else "rules", "model": config.XAI_MODEL if llm.available() else None,
            "embeddings": config.EMBEDDINGS}


@app.get("/api/jobs")
def list_jobs():
    jobs = db.query("SELECT * FROM jobs ORDER BY created_at DESC")
    out = []
    for j in jobs:
        cands = db.query("SELECT score, status FROM candidates WHERE job_id=?", (j["id"],))
        scored = [c["score"] for c in cands if c["score"] is not None]
        out.append({
            "id": j["id"], "title": j["title"], "created_at": j["created_at"],
            "candidates": len(cands), "top_score": max(scored) if scored else None,
            "requirements": db.jload(j["requirements"], {}),
        })
    return out


@app.post("/api/jobs")
def create_job(body: JobIn):
    if len(body.description.strip()) < 20:
        raise HTTPException(400, "Job description is too short.")
    return pipeline.create_job(body.title.strip() or "Untitled role", body.description.strip())


@app.post("/api/demo")
def create_demo():
    job = pipeline.create_job(demo.DEMO_JOB["title"], demo.DEMO_JOB["description"])
    for fname, text in demo.DEMO_RESUMES.items():
        cid = pipeline.ingest(job["id"], fname, text.encode("utf-8"))
        pool.submit(pipeline.process, cid)
    return job


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job = pipeline.get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job


@app.delete("/api/jobs/{job_id}")
def delete_job(job_id: str):
    pipeline.delete_job(job_id)
    return {"ok": True}


@app.post("/api/jobs/{job_id}/resumes")
async def upload(job_id: str, files: list[UploadFile] = File(...)):
    if not pipeline.get_job(job_id):
        raise HTTPException(404, "Job not found")
    ids = []
    for f in files:
        if not f.filename.lower().endswith(ALLOWED):
            continue
        data = await f.read()
        if len(data) > config.MAX_UPLOAD_MB * 1024 * 1024:
            continue
        cid = pipeline.ingest(job_id, f.filename, data)
        ids.append(cid)
        pool.submit(pipeline.process, cid)
    return {"accepted": len(ids), "ids": ids}


@app.get("/api/jobs/{job_id}/candidates")
def candidates(job_id: str):
    rows = db.query("SELECT * FROM candidates WHERE job_id=?", (job_id,))
    items = [_cand_out(c) for c in rows]
    items.sort(key=lambda c: (c["score"] is None, -(c["score"] or 0)))
    for i, c in enumerate(items):
        c["rank"] = i + 1 if c["score"] is not None else None
    return {"candidates": items, "processing": sum(1 for c in items if c["status"] == "processing")}


@app.get("/api/candidates/{cid}")
def candidate(cid: str):
    c = db.one("SELECT * FROM candidates WHERE id=?", (cid,))
    if not c:
        raise HTTPException(404, "Candidate not found")
    return _cand_out(c, full=True)


@app.patch("/api/candidates/{cid}/decision")
def decide(cid: str, body: DecisionIn):
    if body.decision not in ("none", "shortlist", "maybe", "reject"):
        raise HTTPException(400, "Invalid decision")
    db.execute("UPDATE candidates SET decision=? WHERE id=?", (body.decision, cid))
    return {"ok": True}


@app.post("/api/candidates/{cid}/rescore")
def rescore(cid: str):
    db.execute("UPDATE candidates SET status='processing' WHERE id=?", (cid,))
    pool.submit(pipeline.process, cid)
    return {"ok": True}


@app.delete("/api/candidates/{cid}")
def remove_candidate(cid: str):
    pipeline.delete_candidate(cid)
    return {"ok": True}


@app.post("/api/jobs/{job_id}/ask")
def ask(job_id: str, body: AskIn):
    if not body.question.strip():
        raise HTTPException(400, "Empty question")
    return pipeline.ask_pool(job_id, body.question.strip())
