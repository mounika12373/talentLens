"""Built-in demo job and fictional resumes so the app can be shown without any uploads."""

DEMO_JOB = {
    "title": "Machine Learning Engineer (RAG and LLM Applications)",
    "description": """We are hiring a Machine Learning Engineer to build retrieval-augmented generation (RAG) products.

Responsibilities:
- Design, train and evaluate machine learning and NLP models
- Build RAG pipelines using vector databases and large language models
- Ship models as REST APIs and monitor them in production
- Work closely with product and data engineering teams

Requirements:
- 3+ years of experience in machine learning
- Strong Python, PyTorch, scikit-learn and SQL
- Hands-on experience with LLMs, RAG and vector databases
- Docker and Git, experience on AWS

Nice to have:
- Kubernetes, MLOps, FastAPI, Airflow
""",
}

DEMO_RESUMES = {
    "Aarav_Mehta.txt": """Aarav Mehta
Senior Machine Learning Engineer | aarav.mehta@example.com

SUMMARY
Machine learning engineer with 6 years of experience building NLP and LLM products in production.

EXPERIENCE
Senior ML Engineer, Lumen Analytics (2021 - Present)
- Built a RAG platform serving 40k queries per day using ChromaDB, LangChain and large language models.
- Fine-tuned transformer models in PyTorch and deployed them as FastAPI services on AWS (SageMaker, S3).
- Containerised services with Docker and Kubernetes; set up MLflow and CI/CD for MLOps.
- Reduced retrieval latency by 45 percent through hybrid search and better chunking.

ML Engineer, Brightpath (2018 - 2021)
- Developed scikit-learn and PyTorch models for churn and demand forecasting using Python and SQL.
- Orchestrated nightly pipelines with Airflow; used Git for version control.

SKILLS
Python, PyTorch, scikit-learn, SQL, RAG, LLMs, vector databases, Docker, Kubernetes, AWS, FastAPI, Airflow, MLflow, Git

EDUCATION
B.Tech Computer Science
""",
    "Diya_Raman.txt": """Diya Raman
Machine Learning Engineer

SUMMARY
4 years of experience in applied machine learning, recently focused on generative AI.

EXPERIENCE
ML Engineer, Northwind Health (2022 - Present)
- Built a document question answering system with retrieval augmented generation and FAISS.
- Trained NLP classifiers in PyTorch; evaluated with scikit-learn and pandas.
- Exposed models through REST APIs in Flask, packaged with Docker.

Data Scientist, Orbit Retail (2020 - 2022)
- Built demand forecasting models in Python and SQL; dashboards in Tableau.

SKILLS
Python, PyTorch, scikit-learn, SQL, Docker, Git, FAISS, RAG, Flask, Tableau
CLOUD
Some exposure to Azure for model hosting.
""",
    "Kabir_Nair.txt": """Kabir Nair
Data Scientist

SUMMARY
3 years of experience in analytics and classical machine learning.

EXPERIENCE
Data Scientist, Quantix (2023 - Present)
- Built churn and credit risk models with Python, scikit-learn and XGBoost.
- Wrote complex SQL for feature tables; reported insights in Power BI.
- Ran A/B tests and statistical analysis for the marketing team.

Analyst, Finserve (2021 - 2023)
- Automated reporting with Python and Excel; used Git for code sharing.

SKILLS
Python, scikit-learn, SQL, pandas, NumPy, statistics, Power BI, Excel, Git
""",
    "Meera_Iyer.txt": """Meera Iyer
Full Stack Developer

SUMMARY
5 years of experience building web applications.

EXPERIENCE
Full Stack Developer, Pixel Forge (2020 - Present)
- Built React and Node.js applications with REST APIs and PostgreSQL.
- Deployed with Docker on AWS EC2; CI/CD with GitHub Actions.
- Recently experimented with calling LLM APIs to add a chat assistant to a product.

SKILLS
JavaScript, TypeScript, React, Node.js, SQL, Docker, AWS, Git, REST APIs
""",
    "Rohan_Das.txt": """Rohan Das
Recent Graduate, Computer Science

SUMMARY
Final-year student interested in artificial intelligence.

PROJECTS
- Movie recommendation system using Python and pandas.
- Sentiment analysis of tweets with scikit-learn and NLTK.
- Chatbot using a pretrained transformer from Hugging Face (course project).

SKILLS
Python, pandas, NumPy, scikit-learn, Git, HTML, CSS

EDUCATION
B.Tech Computer Science (expected 2026)
""",
    "Sana_Qureshi.txt": """Sana Qureshi
Marketing Manager

SUMMARY
8 years of experience in brand strategy, campaign management and stakeholder communication.

EXPERIENCE
Marketing Manager, Bloom Foods (2018 - Present)
- Led a team of 6; managed a 2 million dollar annual budget.
- Reported campaign performance in Excel; project management with Jira.

SKILLS
Brand strategy, Excel, communication, leadership, project management
""",
}
