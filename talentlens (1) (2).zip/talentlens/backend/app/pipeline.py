"""Core logic: job understanding, resume ingestion, RAG-grounded scoring and analysis, pool Q&A.

Scoring never uses a candidate's name, gender, age, photo or school. The name is stored for display only.
"""
import re

from . import config, db, heuristics, llm, parsing, vectorstore

REQ_SYSTEM = (
    "You are a senior technical recruiter. Read a job description and extract what matters for screening. "
    "Return JSON with keys: must (list of up to 12 short skill names that are clearly required), "
    "nice (list of up to 8 nice-to-have skills), min_years (number, 0 if not stated), "
    "seniority (one of intern, junior, mid, senior, lead, unspecified), summary (one sentence). "
    "Use canonical short names such as Python, PyTorch, Docker, AWS, SQL, RAG. Do not invent skills."
)

ANALYSIS_SYSTEM = (
    "You are an objective, fair recruiting analyst. You receive a job's requirements and, for each requirement, "
    "passages retrieved from one candidate's resume. Judge ONLY from the resume text provided. Ignore the "
    "candidate's name, gender, age, nationality and school prestige. Never invent facts. "
    "Return JSON with keys: headline (max 12 words describing the candidate's profile), years_experience (number), "
    "summary (2 sentences), requirements (list with one object per requirement, in the same order, each with: "
    "skill, status = strong | partial | missing, evidence = a SHORT exact quote copied from the resume (empty if missing), "
    "note = one short sentence), strengths (3 short bullets), gaps (up to 3 short bullets), "
    "red_flags (up to 2 short bullets, empty list if none), interview_questions (3 specific questions probing the gaps and strengths)."
)


# ---------------------------------------------------------------- jobs
def build_requirements(title: str, description: str) -> dict:
    base = heuristics.extract_requirements(title, description)
    if not llm.available():
        return {**base, "source": "rules"}
    try:
        data = llm.chat_json(REQ_SYSTEM, f"Job title: {title}\n\nJob description:\n{description[:6000]}")
        must = [str(s).strip() for s in data.get("must", []) if str(s).strip()][:12]
        nice = [str(s).strip() for s in data.get("nice", []) if str(s).strip()][:8]
        if not must:
            return {**base, "source": "rules"}
        return {
            "must": must,
            "nice": [s for s in nice if s.lower() not in {m.lower() for m in must}],
            "min_years": float(data.get("min_years") or base["min_years"] or 0),
            "seniority": str(data.get("seniority", "")),
            "summary": str(data.get("summary", "")),
            "source": "grok",
        }
    except Exception:
        return {**base, "source": "rules"}


def create_job(title: str, description: str) -> dict:
    req = build_requirements(title, description)
    jid = db.new_id()
    db.execute(
        "INSERT INTO jobs (id, title, description, requirements, min_years, created_at) VALUES (?,?,?,?,?,?)",
        (jid, title, description, db.jdump(req), req.get("min_years", 0), db.now()),
    )
    return get_job(jid)


def get_job(jid: str) -> dict | None:
    j = db.one("SELECT * FROM jobs WHERE id=?", (jid,))
    if not j:
        return None
    j["requirements"] = db.jload(j["requirements"], {})
    return j


# ---------------------------------------------------------------- candidates
def ingest(job_id: str, filename: str, data: bytes) -> str:
    """Parse + chunk + embed into Chroma. Returns candidate id. Scoring happens in process()."""
    text = parsing.normalise(parsing.extract_text(data, filename))
    cid = db.new_id()
    name = heuristics.guess_name(text, filename)
    db.execute(
        "INSERT INTO candidates (id, job_id, filename, name, raw_text, status, created_at) VALUES (?,?,?,?,?,?,?)",
        (cid, job_id, filename, name, text, "processing" if len(text) > 30 else "error", db.now()),
    )
    if len(text) <= 30:
        db.execute(
            "UPDATE candidates SET error=? WHERE id=?",
            ("No readable text found (scanned image PDF?). OCR is not enabled.", cid),
        )
        return cid
    vectorstore.add_chunks(job_id, cid, parsing.chunk(text))
    return cid


def _norm_sem(sim: float) -> float:
    return max(0.0, min(1.0, (sim - 0.15) / 0.5))


def process(cid: str):
    """Score and analyse one candidate. Safe to run in a worker thread."""
    try:
        cand = db.one("SELECT * FROM candidates WHERE id=?", (cid,))
        job = get_job(cand["job_id"])
        req = job["requirements"]
        text = cand["raw_text"]

        reqs = [(s, "must") for s in req.get("must", [])] + [(s, "nice") for s in req.get("nice", [])]

        # 1) RAG retrieval: best resume passages for each requirement
        evidence = {}
        for skill, _ in reqs:
            evidence[skill] = vectorstore.search(f"experience with {skill}", {"candidate_id": cid}, k=2)

        jd_hits = vectorstore.search(job["title"] + "\n" + job["description"][:1500], {"candidate_id": cid}, k=3)
        semantic = _norm_sem(sum(h["similarity"] for h in jd_hits) / len(jd_hits)) if jd_hits else 0.0

        # 2) Judge requirement by requirement (Grok if available, rules otherwise)
        analysis = None
        if llm.available():
            analysis = _llm_analysis(job, reqs, evidence, text)
        if analysis is None:
            analysis = _rule_analysis(job, reqs, evidence, text)

        # 3) Verify claims against the actual resume text (anti-hallucination guard)
        low = text.lower()
        for r in analysis["requirements"]:
            ev = (r.get("evidence") or "").strip().lower()
            verified = bool(ev) and ev[:60] in low
            by_rule = heuristics.has_skill(text, r["skill"])
            r["evidence_verified"] = verified or by_rule
            if r["status"] == "strong" and not (verified or by_rule):
                r["status"] = "partial"
                r["note"] = (r.get("note") or "") + " (Could not verify in resume text.)"
            if r["status"] == "missing" and by_rule:
                r["status"] = "partial"
                r["note"] = (r.get("note") or "") + " (Skill keyword appears in resume.)"
            if not r.get("evidence") and r["status"] != "missing":
                r["evidence"] = heuristics.evidence_line(text, r["skill"]) or (
                    (evidence.get(r["skill"]) or [{"text": ""}])[0]["text"].split("\n")[0][:200])

        # 4) Score
        value = {"strong": 1.0, "partial": 0.5, "missing": 0.0}
        weights = {"must": 2.0, "nice": 1.0}
        total_w = sum(weights[r["importance"]] for r in analysis["requirements"]) or 1.0
        coverage = sum(weights[r["importance"]] * value[r["status"]] for r in analysis["requirements"]) / total_w

        years = float(analysis.get("years_experience") or 0)
        need = float(req.get("min_years") or 0)
        experience = 1.0 if need <= 0 else (min(1.0, years / need) if years > 0 else 0.3)

        final = 100 * (config.W_SKILLS * coverage + config.W_SEMANTIC * semantic + config.W_EXPERIENCE * experience)
        final = round(final, 1)
        analysis["recommendation"] = "Strong match" if final >= 75 else "Worth a look" if final >= 55 else "Weak match"
        missing_must = [r["skill"] for r in analysis["requirements"] if r["importance"] == "must" and r["status"] == "missing"]
        analysis["missing_must"] = missing_must
        scores = {
            "final": final,
            "coverage": round(coverage * 100, 1),
            "semantic": round(semantic * 100, 1),
            "experience": round(experience * 100, 1),
        }
        db.execute(
            "UPDATE candidates SET status='done', score=?, scores=?, analysis=?, error=NULL WHERE id=?",
            (final, db.jdump(scores), db.jdump(analysis), cid),
        )
    except Exception as e:  # never leave a candidate stuck on "processing"
        db.execute("UPDATE candidates SET status='error', error=? WHERE id=?", (str(e)[:300], cid))


def _llm_analysis(job, reqs, evidence, text) -> dict | None:
    blocks = []
    for i, (skill, imp) in enumerate(reqs, 1):
        passages = "\n".join(f"  - ({h['section']}) {h['text'][:350]}" for h in evidence.get(skill, [])) or "  - (no relevant passage)"
        blocks.append(f"{i}. {skill} [{imp}]\n{passages}")
    user = (
        f"Job: {job['title']}\nMinimum years: {job['requirements'].get('min_years', 0)}\n\n"
        f"Requirements with retrieved resume passages:\n" + "\n".join(blocks) +
        f"\n\nResume opening (for overall context):\n{text[:1200]}"
    )
    try:
        data = llm.chat_json(ANALYSIS_SYSTEM, user, max_tokens=2200)
        got = {str(r.get("skill", "")).lower(): r for r in data.get("requirements", [])}
        out_reqs = []
        for skill, imp in reqs:
            r = got.get(skill.lower(), {})
            status = r.get("status", "missing")
            out_reqs.append({
                "skill": skill, "importance": imp,
                "status": status if status in ("strong", "partial", "missing") else "missing",
                "evidence": str(r.get("evidence", ""))[:240], "note": str(r.get("note", ""))[:200],
            })
        return {
            "headline": str(data.get("headline", ""))[:120],
            "years_experience": float(data.get("years_experience") or heuristics.extract_years(text)),
            "summary": str(data.get("summary", "")),
            "requirements": out_reqs,
            "strengths": [str(s) for s in data.get("strengths", [])][:4],
            "gaps": [str(s) for s in data.get("gaps", [])][:4],
            "red_flags": [str(s) for s in data.get("red_flags", [])][:3],
            "interview_questions": [str(s) for s in data.get("interview_questions", [])][:4],
            "engine": "grok",
        }
    except Exception:
        return None


def _rule_analysis(job, reqs, evidence, text) -> dict:
    out = []
    for skill, imp in reqs:
        hits = evidence.get(skill, [])
        by_rule = heuristics.has_skill(text, skill)
        best = hits[0] if hits else None
        if by_rule:
            status, note = "strong", "Skill found in resume."
        elif best and best["similarity"] >= 0.55:
            status, note = "partial", "Related experience found by semantic search."
        else:
            status, note = "missing", "No evidence found."
        ev = ""
        if status == "strong":
            ev = heuristics.evidence_line(text, skill)
        elif status == "partial" and best:
            ev = best["text"].split("\n")[0][:200]
        out.append({"skill": skill, "importance": imp, "status": status, "evidence": ev, "note": note})
    strong = [r["skill"] for r in out if r["status"] == "strong"]
    missing = [r["skill"] for r in out if r["status"] == "missing"]
    years = heuristics.extract_years(text)
    return {
        "headline": heuristics.guess_headline(text) or "Candidate profile",
        "years_experience": years,
        "summary": f"Matches {len(strong)} of {len(out)} requirements"
                   + (f" and shows about {years:g} years of experience." if years else "."),
        "requirements": out,
        "strengths": [f"Demonstrates {s}" for s in strong[:3]],
        "gaps": [f"No evidence of {s}" for s in missing[:3]],
        "red_flags": [],
        "interview_questions": [f"Describe a project where you used {s}." for s in (strong[:2] + missing[:1])],
        "engine": "rules",
    }


# ---------------------------------------------------------------- pool Q&A (RAG)
ASK_SYSTEM = (
    "You help a recruiter query a pool of resumes. Answer ONLY from the passages provided. "
    "Each passage is labelled with the candidate's name. Name the candidates that fit, say why in one line each, "
    "and say clearly when the passages do not contain the answer. Be concise. Do not use outside knowledge."
)


def ask_pool(job_id: str, question: str) -> dict:
    hits = vectorstore.search(question, {"job_id": job_id}, k=10)
    names = {c["id"]: c["name"] for c in db.query("SELECT id, name FROM candidates WHERE job_id=?", (job_id,))}
    sources = [
        {"candidate_id": h["candidate_id"], "name": names.get(h["candidate_id"], "Unknown"),
         "section": h["section"], "text": h["text"][:400], "similarity": round(h["similarity"], 3)}
        for h in hits
    ]
    if not sources:
        return {"answer": "No resumes have been uploaded for this job yet.", "sources": [], "engine": "none"}
    if llm.available():
        ctx = "\n\n".join(f"[{s['name']} | {s['section']}]\n{s['text']}" for s in sources)
        try:
            ans = llm.chat(ASK_SYSTEM, f"Question: {question}\n\nPassages:\n{ctx}", max_tokens=700)
            return {"answer": ans.strip(), "sources": sources, "engine": "grok"}
        except Exception:
            pass
    top = []
    for s in sources:
        if s["name"] not in top:
            top.append(s["name"])
    return {
        "answer": "Closest matches by semantic search: " + ", ".join(top[:5]) +
                  ". (Add an XAI_API_KEY to get a written answer from Grok.)",
        "sources": sources,
        "engine": "rules",
    }


def delete_candidate(cid: str):
    vectorstore.delete_candidate(cid)
    db.execute("DELETE FROM candidates WHERE id=?", (cid,))


def delete_job(jid: str):
    vectorstore.delete_job(jid)
    db.execute("DELETE FROM candidates WHERE job_id=?", (jid,))
    db.execute("DELETE FROM jobs WHERE id=?", (jid,))
