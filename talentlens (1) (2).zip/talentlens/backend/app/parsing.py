"""Resume file parsing and chunking."""
import io
import re

SECTION_WORDS = {
    "summary": "summary", "profile": "summary", "objective": "summary", "about": "summary",
    "experience": "experience", "work experience": "experience", "employment": "experience",
    "professional experience": "experience", "work history": "experience",
    "skills": "skills", "technical skills": "skills", "core competencies": "skills",
    "projects": "projects", "project": "projects", "academic projects": "projects",
    "education": "education", "certifications": "certifications", "certificates": "certifications",
    "achievements": "achievements", "publications": "publications",
}


def extract_text(data: bytes, filename: str) -> str:
    name = filename.lower()
    if name.endswith(".pdf"):
        return _pdf(data)
    if name.endswith(".docx"):
        return _docx(data)
    return data.decode("utf-8", errors="ignore")


def _pdf(data: bytes) -> str:
    text = ""
    try:
        import pdfplumber

        with pdfplumber.open(io.BytesIO(data)) as pdf:
            text = "\n".join((p.extract_text() or "") for p in pdf.pages)
    except Exception:
        text = ""
    if len(text.strip()) < 30:  # fallback parser
        try:
            from pypdf import PdfReader

            reader = PdfReader(io.BytesIO(data))
            text = "\n".join((p.extract_text() or "") for p in reader.pages)
        except Exception:
            pass
    return text


def _docx(data: bytes) -> str:
    from docx import Document

    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" | ".join(cell.text for cell in row.cells))
    return "\n".join(parts)


def normalise(text: str) -> str:
    text = text.replace("\r", "\n").replace(" ", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _heading(line: str) -> str | None:
    key = re.sub(r"[^a-z ]", "", line.lower()).strip()
    if 0 < len(line) <= 40 and key in SECTION_WORDS:
        return SECTION_WORDS[key]
    return None


def chunk(text: str, target: int = 550) -> list[dict]:
    """Split into section-aware chunks of roughly `target` characters."""
    chunks, section, buf = [], "general", ""

    def flush():
        nonlocal buf
        if buf.strip():
            chunks.append({"text": buf.strip(), "section": section})
        buf = ""

    for line in text.split("\n"):
        h = _heading(line.strip())
        if h:
            flush()
            section = h
            continue
        if len(buf) + len(line) > target and buf:
            flush()
        buf += line + "\n"
    flush()
    return chunks or [{"text": text[:target], "section": "general"}]
