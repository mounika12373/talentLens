# TalentLens - AI resume screening with RAG

A recruiter pastes a job description, drops in resumes, and gets a ranked shortlist with evidence for every skill.

**Stack:** Next.js 15 + React 19 + Tailwind CSS 4 + Framer Motion (frontend) | FastAPI (backend) | ChromaDB (vector store) | Grok by xAI (LLM) | SQLite

## How it works (RAG pipeline)

1. **Job understanding** - Grok reads the job description and extracts must-have skills, nice-to-have skills and minimum years.
2. **Ingest** - each resume is parsed (PDF, DOCX, TXT), split into section-aware chunks, embedded, and stored in ChromaDB.
3. **Retrieve** - for every requirement, ChromaDB returns that candidate's most relevant passages ("experience with PyTorch").
4. **Generate** - Grok judges each requirement as strong / partial / missing using ONLY those passages, and quotes the resume as proof. It also writes strengths, gaps, red flags and interview questions.
5. **Verify** - every quote is checked against the real resume text. A claim that cannot be verified is downgraded. This is the guard against hallucination.
6. **Score** - Final = 100 x (0.55 x skills coverage + 0.25 x semantic fit + 0.20 x experience). Must-have skills count double.
7. **Ask the pool** - a chat box that answers recruiter questions ("who has led a team?") from retrieved passages, with sources shown.

Fairness: names, gender, age, photo and school are never used in scoring. Blind review mode hides names in the interface.

Without an `XAI_API_KEY` the app still works in **rules mode** (skill dictionary + embeddings), so you can demo it anywhere.

## Run it on Windows (PowerShell)

Needs Python 3.10+ and Node.js 20+.

**Terminal 1 - backend**
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env      # then open .env and paste your XAI_API_KEY
uvicorn app.main:app --port 8000
```

**Terminal 2 - frontend**
```powershell
cd frontend
npm install
npm run dev
```

Open http://localhost:3000 and click **Try the demo (6 sample resumes)**.

If `pip` fails with `getaddrinfo failed`, it is a network problem (see earlier fix steps: DNS 8.8.8.8, no VPN, or use a hotspot).
The first run also downloads the ~80 MB embedding model once, so it needs internet that time.

On Mac: `python3 -m venv .venv`, `source .venv/bin/activate`, `cp .env.example .env`.

## Project layout

```
backend/app/
  main.py         API routes
  pipeline.py     job extraction, scoring, analysis, pool Q&A
  vectorstore.py  ChromaDB wrapper
  llm.py          Grok client (OpenAI-compatible SDK)
  heuristics.py   rules-mode fallback
  parsing.py      PDF/DOCX/TXT parsing and chunking
  db.py, demo.py, config.py
frontend/
  app/page.tsx              dashboard and new job
  app/jobs/[id]/page.tsx    ranking, filters, blind mode, CSV export
  components/               candidate drawer, ask panel, uploader, UI parts
```

## Questions a mentor may ask

- **Why RAG instead of sending whole resumes to the LLM?** Cheaper, faster, and the model only sees relevant passages, so every judgement has a source.
- **Why ChromaDB?** Open-source, runs locally with no server, persists to disk, built-in cosine search.
- **How do you stop hallucination?** The model must quote the resume; the quote is checked against the text and unverified claims are downgraded.
- **Why not let the LLM score directly?** Scores would be inconsistent. The LLM judges evidence; the score is a transparent formula.
- **How is bias handled?** Protected attributes are excluded from scoring, and blind review hides names.
- **Limitations?** Scanned image PDFs need OCR; rules mode misses synonyms; years of experience is total, not per skill.
