export type Requirements = {
  must: string[];
  nice: string[];
  min_years: number;
  seniority?: string;
  summary?: string;
  source?: string;
};

export type Job = {
  id: string;
  title: string;
  description: string;
  requirements: Requirements;
  created_at: number;
};

export type JobSummary = {
  id: string;
  title: string;
  created_at: number;
  candidates: number;
  top_score: number | null;
  requirements: Requirements;
};

export type Scores = { final: number; coverage: number; semantic: number; experience: number };

export type Candidate = {
  id: string;
  job_id: string;
  filename: string;
  name: string;
  status: "processing" | "done" | "error";
  decision: "none" | "shortlist" | "maybe" | "reject";
  score: number | null;
  scores: Scores | null;
  error: string | null;
  rank?: number | null;
  headline?: string;
  recommendation?: string;
  years_experience?: number;
  missing_must?: string[];
  matched?: number;
  total_reqs?: number;
  engine?: string;
};

export type ReqResult = {
  skill: string;
  importance: "must" | "nice";
  status: "strong" | "partial" | "missing";
  evidence: string;
  note: string;
  evidence_verified?: boolean;
};

export type CandidateDetail = Candidate & {
  resume_text: string;
  analysis: {
    headline: string;
    years_experience: number;
    summary: string;
    requirements: ReqResult[];
    strengths: string[];
    gaps: string[];
    red_flags: string[];
    interview_questions: string[];
    recommendation: string;
    missing_must: string[];
    engine: string;
  } | null;
};

export type AskResult = {
  answer: string;
  engine: string;
  sources: { candidate_id: string; name: string; section: string; text: string; similarity: number }[];
};

export type Health = { ok: boolean; llm: "grok" | "rules"; model: string | null; embeddings: string };
