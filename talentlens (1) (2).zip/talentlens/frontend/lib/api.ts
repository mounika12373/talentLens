import type { AskResult, Candidate, CandidateDetail, Health, Job, JobSummary } from "./types";

export const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, init);
  if (!res.ok) {
    let msg = res.statusText;
    try {
      msg = (await res.json()).detail || msg;
    } catch {}
    throw new Error(msg);
  }
  return res.json();
}

const json = (method: string, body?: unknown): RequestInit => ({
  method,
  headers: { "Content-Type": "application/json" },
  body: body ? JSON.stringify(body) : undefined,
});

export const api = {
  health: () => req<Health>("/api/health"),
  jobs: () => req<JobSummary[]>("/api/jobs"),
  job: (id: string) => req<Job>(`/api/jobs/${id}`),
  createJob: (title: string, description: string) => req<Job>("/api/jobs", json("POST", { title, description })),
  demo: () => req<Job>("/api/demo", json("POST")),
  deleteJob: (id: string) => req<{ ok: boolean }>(`/api/jobs/${id}`, json("DELETE")),
  candidates: (jobId: string) =>
    req<{ candidates: Candidate[]; processing: number }>(`/api/jobs/${jobId}/candidates`),
  candidate: (id: string) => req<CandidateDetail>(`/api/candidates/${id}`),
  decide: (id: string, decision: string) => req(`/api/candidates/${id}/decision`, json("PATCH", { decision })),
  removeCandidate: (id: string) => req(`/api/candidates/${id}`, json("DELETE")),
  ask: (jobId: string, question: string) => req<AskResult>(`/api/jobs/${jobId}/ask`, json("POST", { question })),
  upload: async (jobId: string, files: File[]) => {
    const fd = new FormData();
    files.forEach((f) => fd.append("files", f));
    const res = await fetch(`${API}/api/jobs/${jobId}/resumes`, { method: "POST", body: fd });
    if (!res.ok) throw new Error("Upload failed");
    return res.json() as Promise<{ accepted: number }>;
  },
};
