"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ScanSearch } from "lucide-react";
import { api } from "@/lib/api";
import type { Health } from "@/lib/types";

export function TopBar() {
  const [h, setH] = useState<Health | null>(null);
  const [down, setDown] = useState(false);

  useEffect(() => {
    api.health().then(setH).catch(() => setDown(true));
  }, []);

  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-[#07070d]/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-black">
            <ScanSearch size={19} strokeWidth={2.4} />
          </span>
          <span className="text-lg font-semibold tracking-tight">
            Talent<span className="grad-text">Lens</span>
          </span>
        </Link>
        <div className="flex items-center gap-2 text-xs">
          {down ? (
            <Pill color="rose">Backend offline - start it on port 8000</Pill>
          ) : h ? (
            <>
              <Pill color={h.llm === "grok" ? "emerald" : "amber"}>
                {h.llm === "grok" ? `Grok connected (${h.model})` : "Rules mode - add XAI_API_KEY for Grok"}
              </Pill>
              <Pill color="violet">ChromaDB RAG</Pill>
            </>
          ) : null}
        </div>
      </div>
    </header>
  );
}

function Pill({ color, children }: { color: "emerald" | "amber" | "rose" | "violet"; children: React.ReactNode }) {
  const map = {
    emerald: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
    amber: "border-amber-400/30 bg-amber-400/10 text-amber-300",
    rose: "border-rose-400/30 bg-rose-400/10 text-rose-300",
    violet: "border-violet-400/30 bg-violet-400/10 text-violet-300",
  };
  return <span className={`rounded-full border px-3 py-1 font-medium ${map[color]}`}>{children}</span>;
}
