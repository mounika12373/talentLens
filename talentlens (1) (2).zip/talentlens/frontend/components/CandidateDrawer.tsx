"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, FileText, HelpCircle, Quote, ShieldCheck, Star, ThumbsDown, X } from "lucide-react";
import { api } from "@/lib/api";
import type { CandidateDetail } from "@/lib/types";
import { Bar, ScoreRing, SkillChip, StatusIcon, initials, scoreTone } from "./ui";

type Props = {
  id: string | null;
  blind: boolean;
  rank?: number | null;
  onClose: () => void;
  onDecision: (id: string, d: string) => void;
};

export function CandidateDrawer({ id, blind, rank, onClose, onDecision }: Props) {
  const [data, setData] = useState<CandidateDetail | null>(null);
  const [tab, setTab] = useState<"analysis" | "resume">("analysis");

  useEffect(() => {
    setData(null);
    setTab("analysis");
    if (id) api.candidate(id).then(setData).catch(() => {});
  }, [id]);

  const a = data?.analysis;
  const display = blind ? `Candidate #${rank ?? ""}` : data?.name ?? "";
  const tone = scoreTone(data?.score);

  function decide(d: string) {
    if (!data) return;
    const next = data.decision === d ? "none" : d;
    setData({ ...data, decision: next as CandidateDetail["decision"] });
    onDecision(data.id, next);
  }

  return (
    <AnimatePresence>
      {id && (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.aside
            className="fixed right-0 top-0 z-50 flex h-full w-full max-w-[760px] flex-col border-l border-white/10 bg-[#0b0b14]"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 32, stiffness: 300 }}
          >
            <div className="flex items-start gap-4 border-b border-white/8 p-6">
              {data ? <ScoreRing score={data.score} size={76} /> : <div className="shimmer h-[76px] w-[76px] rounded-full" />}
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/8 text-sm font-semibold">
                    {blind ? "?" : initials(data?.name || "")}
                  </span>
                  <h2 className="truncate text-xl font-semibold">{display || "Loading..."}</h2>
                </div>
                <p className="mt-1 text-sm text-zinc-400">{a?.headline}</p>
                {data && (
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <span className={`text-sm font-semibold ${tone.text}`}>{a?.recommendation}</span>
                    {a && a.years_experience > 0 && <SkillChip>{a.years_experience} yrs experience</SkillChip>}
                    <SkillChip>{a?.engine === "grok" ? "Analysed by Grok" : "Rules engine"}</SkillChip>
                  </div>
                )}
              </div>
              <button onClick={onClose} className="btn-ghost p-2" aria-label="Close">
                <X size={18} />
              </button>
            </div>

            <div className="flex items-center gap-2 border-b border-white/8 px-6 py-3">
              <button
                onClick={() => decide("shortlist")}
                className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm ${
                  data?.decision === "shortlist" ? "border-emerald-400/50 bg-emerald-400/15 text-emerald-200" : "btn-ghost"
                }`}
              >
                <Star size={14} /> Shortlist
              </button>
              <button
                onClick={() => decide("maybe")}
                className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm ${
                  data?.decision === "maybe" ? "border-amber-400/50 bg-amber-400/15 text-amber-200" : "btn-ghost"
                }`}
              >
                <HelpCircle size={14} /> Maybe
              </button>
              <button
                onClick={() => decide("reject")}
                className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm ${
                  data?.decision === "reject" ? "border-rose-400/50 bg-rose-400/15 text-rose-200" : "btn-ghost"
                }`}
              >
                <ThumbsDown size={14} /> Reject
              </button>
              <div className="ml-auto flex rounded-lg bg-white/5 p-1 text-sm">
                {(["analysis", "resume"] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTab(t)}
                    className={`rounded-md px-3 py-1 capitalize ${tab === t ? "bg-white/12 text-white" : "text-zinc-400"}`}
                  >
                    {t === "resume" ? "Resume text" : "Analysis"}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              {!data ? (
                <div className="space-y-3">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="shimmer h-16 rounded-xl" />
                  ))}
                </div>
              ) : tab === "resume" ? (
                <pre className="whitespace-pre-wrap rounded-xl border border-white/8 bg-white/3 p-4 text-sm leading-relaxed text-zinc-300">
                  {data.resume_text}
                </pre>
              ) : !a || !data.scores ? (
                <div className="rounded-xl border border-rose-400/30 bg-rose-400/10 p-4 text-rose-200">
                  {data.error || "This resume is still being processed."}
                </div>
              ) : (
                <div className="space-y-7">
                  <p className="text-[15px] leading-relaxed text-zinc-300">{a.summary}</p>

                  <section>
                    <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-500">Score breakdown</h3>
                    <div className="grid gap-4 sm:grid-cols-3">
                      <Bar label="Skills coverage" value={data.scores.coverage} hint="55% of final" />
                      <Bar label="Semantic fit" value={data.scores.semantic} hint="25% of final" />
                      <Bar label="Experience" value={data.scores.experience} hint="20% of final" />
                    </div>
                  </section>

                  {a.missing_must.length > 0 && (
                    <div className="flex items-start gap-3 rounded-xl border border-rose-400/25 bg-rose-400/8 p-4">
                      <AlertTriangle size={18} className="mt-0.5 shrink-0 text-rose-300" />
                      <div className="text-sm">
                        <div className="font-medium text-rose-200">Missing must-have skills</div>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {a.missing_must.map((m) => (
                            <SkillChip key={m} tone="bad">
                              {m}
                            </SkillChip>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  <section>
                    <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-500">Requirements and evidence</h3>
                    <div className="space-y-2">
                      {a.requirements.map((r) => (
                        <div key={r.skill} className="rounded-xl border border-white/8 bg-white/3 p-3.5">
                          <div className="flex items-center gap-3">
                            <StatusIcon status={r.status} />
                            <span className="font-medium">{r.skill}</span>
                            <SkillChip tone={r.importance === "must" ? "must" : "nice"}>{r.importance === "must" ? "must-have" : "nice-to-have"}</SkillChip>
                            {r.evidence_verified && r.status !== "missing" && (
                              <span className="ml-auto flex items-center gap-1 text-[11px] text-emerald-300/80" title="Evidence found in the resume text">
                                <ShieldCheck size={13} /> verified
                              </span>
                            )}
                          </div>
                          {r.evidence && (
                            <div className="mt-2 flex gap-2 pl-9 text-[13px] italic text-zinc-400">
                              <Quote size={13} className="mt-0.5 shrink-0 text-zinc-600" />
                              <span>{r.evidence}</span>
                            </div>
                          )}
                          {r.note && <div className="mt-1 pl-9 text-xs text-zinc-500">{r.note}</div>}
                        </div>
                      ))}
                    </div>
                  </section>

                  <div className="grid gap-5 sm:grid-cols-2">
                    <List title="Strengths" items={a.strengths} icon={<CheckCircle2 size={15} className="text-emerald-300" />} />
                    <List title="Gaps" items={a.gaps} icon={<AlertTriangle size={15} className="text-amber-300" />} />
                  </div>
                  {a.red_flags.length > 0 && (
                    <List title="Red flags" items={a.red_flags} icon={<AlertTriangle size={15} className="text-rose-300" />} />
                  )}
                  <section>
                    <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-500">Suggested interview questions</h3>
                    <ol className="list-decimal space-y-2 pl-5 text-sm text-zinc-300">
                      {a.interview_questions.map((q, i) => (
                        <li key={i}>{q}</li>
                      ))}
                    </ol>
                  </section>
                  <p className="flex items-center gap-2 pb-4 text-xs text-zinc-600">
                    <FileText size={13} /> {data.filename}. Scoring ignores name, gender, age and school.
                  </p>
                </div>
              )}
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function List({ title, items, icon }: { title: string; items: string[]; icon: React.ReactNode }) {
  return (
    <section>
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-500">{title}</h3>
      <ul className="space-y-2 text-sm text-zinc-300">
        {items.map((s, i) => (
          <li key={i} className="flex gap-2">
            <span className="mt-0.5 shrink-0">{icon}</span>
            {s}
          </li>
        ))}
        {items.length === 0 && <li className="text-zinc-500">None found</li>}
      </ul>
    </section>
  );
}
