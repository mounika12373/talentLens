"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Bot, Loader2, SendHorizonal, User } from "lucide-react";
import { api } from "@/lib/api";
import type { AskResult } from "@/lib/types";

type Msg = { role: "user"; text: string } | { role: "ai"; res: AskResult };

const SUGGESTIONS = [
  "Who has built RAG systems with vector databases?",
  "Who has experience deploying models on AWS?",
  "Which candidates have led or mentored a team?",
  "Who has worked with Kubernetes?",
];

export function AskPanel({ jobId, blind }: { jobId: string; blind: boolean }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  async function send(text: string) {
    if (!text.trim() || busy) return;
    setMsgs((m) => [...m, { role: "user", text }]);
    setQ("");
    setBusy(true);
    try {
      const res = await api.ask(jobId, text);
      setMsgs((m) => [...m, { role: "ai", res }]);
    } catch {
      setMsgs((m) => [...m, { role: "ai", res: { answer: "Something went wrong. Is the backend running?", sources: [], engine: "none" } }]);
    }
    setBusy(false);
    setTimeout(() => end.current?.scrollIntoView({ behavior: "smooth" }), 50);
  }

  return (
    <div className="glass flex h-[620px] flex-col p-5">
      <div className="flex-1 space-y-4 overflow-y-auto pr-1">
        {msgs.length === 0 && (
          <div className="grid h-full place-items-center text-center">
            <div>
              <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/30 to-cyan-400/30 text-violet-200">
                <Bot size={22} />
              </div>
              <div className="font-medium">Ask your candidate pool anything</div>
              <p className="mx-auto mt-1 max-w-sm text-sm text-zinc-500">
                Answers come from retrieved resume passages in ChromaDB, with the source shown for each one.
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => send(s)} className="btn-ghost px-3 py-1.5 text-xs text-zinc-300">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        {msgs.map((m, i) =>
          m.role === "user" ? (
            <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="flex justify-end gap-2">
              <div className="max-w-[80%] rounded-2xl rounded-tr-sm bg-violet-500/20 px-4 py-2.5 text-sm">{m.text}</div>
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/8">
                <User size={15} />
              </span>
            </motion.div>
          ) : (
            <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="flex gap-2">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 text-black">
                <Bot size={15} />
              </span>
              <div className="max-w-[88%]">
                <div className="whitespace-pre-wrap rounded-2xl rounded-tl-sm bg-white/5 px-4 py-2.5 text-sm leading-relaxed">
                  {blind ? maskNames(m.res) : m.res.answer}
                </div>
                {m.res.sources.length > 0 && (
                  <details className="mt-2 text-xs text-zinc-500">
                    <summary className="cursor-pointer select-none hover:text-zinc-300">{m.res.sources.length} retrieved passages</summary>
                    <div className="mt-2 space-y-2">
                      {m.res.sources.slice(0, 5).map((s, j) => (
                        <div key={j} className="rounded-lg border border-white/8 bg-white/3 p-2.5">
                          <div className="mb-1 flex justify-between text-zinc-400">
                            <span>{blind ? "Hidden" : s.name} - {s.section}</span>
                            <span>{Math.round(s.similarity * 100)}% match</span>
                          </div>
                          <div className="line-clamp-3 text-zinc-500">{s.text}</div>
                        </div>
                      ))}
                    </div>
                  </details>
                )}
              </div>
            </motion.div>
          )
        )}
        {busy && (
          <div className="flex items-center gap-2 text-sm text-zinc-500">
            <Loader2 size={15} className="animate-spin" /> Searching resumes...
          </div>
        )}
        <div ref={end} />
      </div>
      <form
        className="mt-4 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          send(q);
        }}
      >
        <input className="input" placeholder="e.g. Who has production experience with LLM agents?" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn-primary px-4" disabled={busy || !q.trim()} aria-label="Send">
          <SendHorizonal size={18} />
        </button>
      </form>
    </div>
  );
}

// In blind mode, hide candidate names that appear in the answer text.
function maskNames(res: AskResult) {
  let text = res.answer;
  const seen = new Set<string>();
  res.sources.forEach((s) => seen.add(s.name));
  Array.from(seen).forEach((n, i) => {
    text = text.split(n).join(`Candidate ${String.fromCharCode(65 + i)}`);
  });
  return text;
}
