"use client";

import { useRef, useState } from "react";
import { CloudUpload, Loader2 } from "lucide-react";
import { api } from "@/lib/api";

export function Uploader({ jobId, onDone }: { jobId: string; onDone: () => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function handle(list: FileList | File[]) {
    const files = Array.from(list).filter((f) => /\.(pdf|docx|txt|md)$/i.test(f.name));
    if (!files.length) {
      setMsg("Please choose PDF, DOCX or TXT files.");
      return;
    }
    setBusy(true);
    setMsg("");
    try {
      const r = await api.upload(jobId, files);
      setMsg(`${r.accepted} resume${r.accepted === 1 ? "" : "s"} uploaded. Analysing now...`);
      onDone();
    } catch {
      setMsg("Upload failed. Is the backend running?");
    }
    setBusy(false);
  }

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDrag(true);
      }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDrag(false);
        handle(e.dataTransfer.files);
      }}
      onClick={() => input.current?.click()}
      className={`cursor-pointer rounded-2xl border-2 border-dashed p-6 text-center transition ${
        drag ? "border-violet-400 bg-violet-400/10" : "border-white/12 bg-white/3 hover:border-white/25"
      }`}
    >
      <input ref={input} type="file" multiple accept=".pdf,.docx,.txt,.md" className="hidden" onChange={(e) => e.target.files && handle(e.target.files)} />
      <div className="mx-auto mb-2 grid h-11 w-11 place-items-center rounded-xl bg-white/8 text-violet-300">
        {busy ? <Loader2 className="animate-spin" size={20} /> : <CloudUpload size={20} />}
      </div>
      <div className="font-medium">Drop resumes here or click to browse</div>
      <div className="mt-0.5 text-xs text-zinc-500">PDF, DOCX or TXT. Upload as many as you like.</div>
      {msg && <div className="mt-3 text-sm text-cyan-300">{msg}</div>}
    </div>
  );
}
