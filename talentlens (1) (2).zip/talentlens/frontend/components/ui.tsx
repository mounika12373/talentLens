import { Check, Minus, X } from "lucide-react";

export function scoreTone(score: number | null | undefined) {
  if (score == null) return { text: "text-zinc-400", stroke: "#71717a", label: "Scoring" };
  if (score >= 75) return { text: "text-emerald-300", stroke: "#34d399", label: "Strong match" };
  if (score >= 55) return { text: "text-amber-300", stroke: "#fbbf24", label: "Worth a look" };
  return { text: "text-rose-300", stroke: "#fb7185", label: "Weak match" };
}

export function ScoreRing({ score, size = 64 }: { score: number | null | undefined; size?: number }) {
  const r = size / 2 - 6;
  const c = 2 * Math.PI * r;
  const pct = score == null ? 0 : Math.max(0, Math.min(100, score)) / 100;
  const tone = scoreTone(score);
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="5" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={tone.stroke}
          strokeWidth="5"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ transition: "stroke-dashoffset 0.9s cubic-bezier(.2,.8,.2,1)" }}
        />
      </svg>
      <div className={`absolute inset-0 grid place-items-center font-semibold ${tone.text}`} style={{ fontSize: size * 0.3 }}>
        {score == null ? "..." : Math.round(score)}
      </div>
    </div>
  );
}

export function Bar({ label, value, hint }: { label: string; value: number; hint?: string }) {
  const tone = scoreTone(value);
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="text-zinc-300">{label}</span>
        <span className={`font-semibold ${tone.text}`}>{Math.round(value)}%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-white/8">
        <div
          className="h-full rounded-full"
          style={{ width: `${value}%`, background: tone.stroke, transition: "width 0.9s cubic-bezier(.2,.8,.2,1)" }}
        />
      </div>
      {hint && <div className="mt-1 text-[11px] text-zinc-500">{hint}</div>}
    </div>
  );
}

export function SkillChip({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "must" | "nice" | "good" | "bad" | "neutral";
}) {
  const map = {
    must: "border-violet-400/30 bg-violet-400/10 text-violet-200",
    nice: "border-cyan-400/25 bg-cyan-400/10 text-cyan-200",
    good: "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
    bad: "border-rose-400/30 bg-rose-400/10 text-rose-200",
    neutral: "border-white/10 bg-white/5 text-zinc-300",
  };
  return <span className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${map[tone]}`}>{children}</span>;
}

export function StatusIcon({ status }: { status: "strong" | "partial" | "missing" }) {
  if (status === "strong")
    return (
      <span className="grid h-6 w-6 place-items-center rounded-full bg-emerald-400/15 text-emerald-300">
        <Check size={14} strokeWidth={3} />
      </span>
    );
  if (status === "partial")
    return (
      <span className="grid h-6 w-6 place-items-center rounded-full bg-amber-400/15 text-amber-300">
        <Minus size={14} strokeWidth={3} />
      </span>
    );
  return (
    <span className="grid h-6 w-6 place-items-center rounded-full bg-rose-400/15 text-rose-300">
      <X size={14} strokeWidth={3} />
    </span>
  );
}

export function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}
