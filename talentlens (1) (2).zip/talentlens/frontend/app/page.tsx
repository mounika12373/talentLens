"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Briefcase, Database, EyeOff, Loader2, Sparkles, Trash2, Users, Wand2 } from "lucide-react";
import { api } from "@/lib/api";
import type { JobSummary } from "@/lib/types";
import { SkillChip, scoreTone } from "@/components/ui";

const features = [
  { icon: Database, title: "RAG over every resume", text: "Resumes are chunked into ChromaDB, so each requirement is checked against real passages." },
  { icon: Sparkles, title: "Grok-powered analysis", text: "Strengths, gaps, red flags and interview questions, each backed by a quote from the resume." },
  { icon: EyeOff, title: "Blind review mode", text: "Scoring ignores names, gender, age and school. Hide names in the list with one click." },
];

export default function Home() {
  const router = useRouter();
  const [jobs, setJobs] = useState<JobSummary[] | null>(null);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [busy, setBusy] = useState<"" | "create" | "demo">("");
  const [err, setErr] = useState("");

  const load = () => api.jobs().then(setJobs).catch(() => setJobs([]));
  useEffect(() => {
    load();
  }, []);

  async function create() {
    setErr("");
    setBusy("create");
    try {
      const job = await api.createJob(title, desc);
      router.push(`/jobs/${job.id}`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not create the job. Is the backend running?");
      setBusy("");
    }
  }

  async function demo() {
    setErr("");
    setBusy("demo");
    try {
      const job = await api.demo();
      router.push(`/jobs/${job.id}`);
    } catch {
      setErr("Could not reach the backend. Start it on port 8000 first.");
      setBusy("");
    }
  }

  return (
    <div>
      <section className="pb-10 pt-8 text-center">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-zinc-300">
            <Sparkles size={13} className="text-violet-300" /> Screen 100 resumes in the time it takes to read one
          </span>
          <h1 className="mx-auto mt-5 max-w-3xl text-4xl font-semibold leading-tight tracking-tight md:text-6xl">
            Hire faster with <span className="grad-text">explainable</span> resume ranking
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-zinc-400">
            Paste a job description, drop in resumes, and get a ranked shortlist with evidence for every skill. No black
            box: every score links back to a line in the resume.
          </p>
        </motion.div>
      </section>

      <div className="grid gap-6 lg:grid-cols-5">
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="glass p-6 lg:col-span-3"
        >
          <div className="mb-4 flex items-center gap-2 text-sm font-medium text-zinc-300">
            <Briefcase size={16} /> New job
          </div>
          <input className="input mb-3" placeholder="Job title, e.g. Machine Learning Engineer" value={title} onChange={(e) => setTitle(e.target.value)} />
          <textarea
            className="input h-56 resize-none"
            placeholder="Paste the full job description here..."
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
          />
          {err && <div className="mt-3 rounded-lg border border-rose-400/30 bg-rose-400/10 px-3 py-2 text-sm text-rose-200">{err}</div>}
          <div className="mt-4 flex flex-wrap gap-3">
            <button className="btn-primary flex items-center gap-2 px-5 py-2.5" disabled={!title.trim() || desc.trim().length < 20 || !!busy} onClick={create}>
              {busy === "create" ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}
              {busy === "create" ? "Reading the job..." : "Create job and extract skills"}
            </button>
            <button className="btn-ghost flex items-center gap-2 px-5 py-2.5 text-sm" disabled={!!busy} onClick={demo}>
              {busy === "demo" ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
              Try the demo (6 sample resumes)
            </button>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="space-y-3 lg:col-span-2"
        >
          {features.map((f) => (
            <div key={f.title} className="glass flex gap-4 p-5">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/6 text-violet-300">
                <f.icon size={19} />
              </span>
              <div>
                <div className="font-medium">{f.title}</div>
                <div className="mt-0.5 text-sm text-zinc-400">{f.text}</div>
              </div>
            </div>
          ))}
        </motion.section>
      </div>

      <section className="mt-12">
        <h2 className="mb-4 text-lg font-semibold">Your jobs</h2>
        {jobs === null ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="shimmer h-32 rounded-2xl" />
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <div className="glass p-8 text-center text-zinc-400">No jobs yet. Create one above or try the demo.</div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {jobs.map((j) => {
              const tone = scoreTone(j.top_score);
              return (
                <Link key={j.id} href={`/jobs/${j.id}`} className="glass group relative p-5 transition hover:border-violet-400/40">
                  <div className="pr-8 font-medium leading-snug">{j.title}</div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {j.requirements.must?.slice(0, 4).map((s) => (
                      <SkillChip key={s} tone="must">
                        {s}
                      </SkillChip>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center justify-between text-sm text-zinc-400">
                    <span className="flex items-center gap-1.5">
                      <Users size={14} /> {j.candidates} candidates
                    </span>
                    <span className={tone.text}>{j.top_score != null ? `Top ${Math.round(j.top_score)}` : "No scores yet"}</span>
                  </div>
                  <ArrowRight size={16} className="absolute right-5 top-5 text-zinc-500 transition group-hover:translate-x-1 group-hover:text-violet-300" />
                  <button
                    className="absolute bottom-3 right-3 hidden rounded-lg p-1.5 text-zinc-500 hover:bg-rose-400/10 hover:text-rose-300 group-hover:block"
                    title="Delete job"
                    onClick={async (e) => {
                      e.preventDefault();
                      await api.deleteJob(j.id);
                      load();
                    }}
                  >
                    <Trash2 size={14} />
                  </button>
                </Link>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
