import type { Metadata } from "next";
import "./globals.css";
import { TopBar } from "@/components/TopBar";

export const metadata: Metadata = {
  title: "TalentLens - AI resume screening",
  description: "ATS-friendly resume ranking with RAG, ChromaDB and Grok",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <TopBar />
        <main className="mx-auto max-w-7xl px-5 pb-24 pt-6">{children}</main>
      </body>
    </html>
  );
}
