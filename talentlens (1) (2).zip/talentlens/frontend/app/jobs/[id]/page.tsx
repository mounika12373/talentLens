"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, Download, Eye, EyeOff, Loader2, MessageSquare, Trash2, Trophy, Users } from "lucide-react";
import { api } from "@/lib/api";
import type { Candidate, Job } from "@/lib/types";
import { ScoreRing, SkillChip, initials, scoreTone } from "@/components/ui";
import { Uploader } from "@/components/Uploader";
import { CandidateDrawer } from "@/components/CandidateDrawer";
import { AskPanel } from "@/components/AskPanel";

type Filter = "all" | "shortlist" | "maybe" | "reject";

export default function JobPage() {
  const { id } = useParams<{ id: string }>();
  const [job, setJob] = useState<Job | null>(null);
  const [cands, setCands] = useState<Candidate[]>([]);
  const [processing, setProcessing] = useState(0);
  const [open, setOpen] = useState<string | null>(null);
  const [blind, setBlind] = useState(false);
  const [view, setView] = useState<"rank" | "ask">("rank");
  const [filter, setFilter] = useState<Filter>("all");
  const [minScore, setMinScore] = useState(0);
  const [loaded, setLoaded] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const r = await api.candidates(id);
      setCands(r.candidates);
      setProcessing(r.processing);
    } finally {
      setLoaded(true);
    }
  }, [id]);

  useEffect(() => {
    api.job(id).then(setJob).catch(() => {});
    refresh();
  }, [id, refresh]);

  // poll while resumes are being analysed
  useEffect(() => {
    if (processing === 0) return;
    const t = setInterval(refresh, 1500);
    return () => clearInterval(t);
  }, [processing, refresh]);

  const done = cands.filter((c) => c.score != null);
  const stats = useMemo(() => {
    const scores = done.map((c) => c.score as number);
    return {
      total: cands.length,
      top: scores.length ? Math.max(...scores) : null,
      avg: scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : null,
      strong: scores.filter((s) => s >= 75).length,
      shortlisted: cands.filter((c) => c.decision === "shortlist").length,
    };
  }, [cands, done]);

  const shown = cands.filter((c) => (filter === "all" || c.decision === filter) && (c.score == null || c.score >= minScore));

  async function decide(cid: string, d: string) {
    setCands((cs) => cs.map((c) => (c.id === cid ? { ...c, decision: d as Candidate["decision"] } : c)));
    await api.decide(cid, d);
  }

  function exportCsv() {
    const rows = [["Rank", "Name", "Score", "Recommendation", "Skills coverage", "Semantic fit", "Experience", "Missing must-have", "Decision"]];
    cands.forEach((c) =>
      rows.push([
        String(c.rank ?? ""), c.name, String(c.score ?? ""), c.recommendation ?? "",
        String(c.scores?.coverage ?? ""), String(c.scores?.semantic ?? ""), String(c.scores?.experience ?? ""),
        (c.missing_must ?? []).join("; "), c.decision,
      ])
    );
    const csv = rows.map((r) => r.map((v) => `"${v.replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `${(job?.title ?? "candidates").replace(/\W+/g, "_")}_ranking.csv`;
    a.click();
  }

  const openRank = cands.find((c) => c.id === open)?.rank;

  return (
    <div>
      <Link href="/" className="mb-4 inline-flex items-center gap-1.5 text-sm text-zinc-400 hover:text-white">
        <ArrowLeft size={15} /> All jobs
      </Link>

      {/* header */}
      <div className="glass mb-6 p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <h1 className="text-2xl font-semibold tracking-tight">{job?.title ?? "Loading..."}</h1>
            {job?.requirements.summary && <p className="mt-1 text-sm text-zinc-400">{job.requirements.summary}</p>}
          </div>
          <div className="flex gap-2">
            <button onClick={() => setBlind((b) => !b)} className={`flex items-center gap-2 px-4 py-2 text-sm ${blind ? "btn-primary" : "btn-ghost"}`}>
              {blind ? <EyeOff size={15} /> : <Eye size={15} />} Blind review {blind ? "on" : "off"}
            </button>
            <button onClick={exportCsv} className="btn-ghost flex items-center gap-2 px-4 py-2 text-sm" disabled={!cands.length}>
              <Download size={15} /> Export CSV
            </button>
          </div>
        </div>
        {job && (
          <div className="mt-4 flex flex-wrap items-center gap-1.5">
            <span className="mr-1 text-xs uppercase tracking-wider text-zinc-500">Must-have</span>
            {job.requirements.must.map((s) => (
              <SkillChip key={s} tone="must">{s}</SkillChip>
            ))}
            {job.requirements.nice.length > 0 && <span className="ml-3 mr-1 text-xs uppercase tracking-wider text-zinc-500">Nice-to-have</span>}
            {job.requirements.nice.map((s) => (
              <SkillChip key={s} tone="nice">{s}</SkillChip>
            ))}
            {job.requirements.min_years > 0 && <SkillChip>{job.requirements.min_years}+ yrs</SkillChip>}
          </div>
        )}
      </div>

      {/* stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Candidates" value={String(stats.total)} icon={<Users size={16} />} />
        <Stat label="Top score" value={stats.top != null ? String(Math.round(stats.top)) : "-"} icon={<Trophy size={16} />} />
        <Stat label="Average score" value={stats.avg != null ? String(Math.round(stats.avg)) : "-"} />
        <Stat label="Strong matches" value={String(stats.strong)} sub={`${stats.shortlisted} shortlisted`} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-1">
          <Uploader jobId={id} onDone={refresh} />
          <div className="glass space-y-4 p-5">
            <div className="text-sm font-medium">Filters</div>
            <div className="flex flex-wrap gap-2">
              {(["all", "shortlist", "maybe", "reject"] as Filter[]).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`rounded-lg px-3 py-1.5 text-xs capitalize ${filter === f ? "bg-violet-500/25 text-violet-100" : "btn-ghost"}`}
                >
                  {f}
                </button>
              ))}
            </div>
            <div>
              <div className="mb-1 flex justify-between text-xs text-zinc-400">
                <span>Minimum score</span>
                <span>{minScore}</span>
              </div>
              <input type="range" min={0} max={90} step={5} value={minScore} onChange={(e) => setMinScore(+e.target.value)} className="w-full accent-violet-400" />
            </div>
          </div>
          <div className="glass p-5 text-xs leading-relaxed text-zinc-500">
            <div className="mb-1 text-sm font-medium text-zinc-300">How the score works</div>
            Skills coverage 55% + semantic fit 25% + experience 20%. Must-have skills count double. Names, gender, age and
            school are never used.
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="mb-4 flex w-fit rounded-xl bg-white/5 p-1 text-sm">
            <button onClick={() => setView("rank")} className={`flex items-center gap-2 rounded-lg px-4 py-2 ${view === "rank" ? "bg-white/12" : "text-zinc-400"}`}>
              <Trophy size={15} /> Ranking
            </button>
            <button onClick={() => setView("ask")} className={`flex items-center gap-2 rounded-lg px-4 py-2 ${view === "ask" ? "bg-white/12" : "text-zinc-400"}`}>
              <MessageSquare size={15} /> Ask the pool
            </button>
          </div>

          {view === "ask" ? (
            <AskPanel jobId={id} blind={blind} />
          ) : (
            <div className="space-y-3">
              {processing > 0 && (
                <div className="flex items-center gap-2 rounded-xl border border-cyan-400/25 bg-cyan-400/8 px-4 py-2.5 text-sm text-cyan-200">
                  <Loader2 size={15} className="animate-spin" /> Analysing {processing} resume{processing > 1 ? "s" : ""}...
                </div>
              )}
              {!loaded && [0, 1, 2].map((i) => <div key={i} className="shimmer h-24 rounded-2xl" />)}
              {loaded && cands.length === 0 && (
                <div className="glass p-10 text-center text-zinc-400">Upload resumes to see the ranking.</div>
              )}
              <AnimatePresence initial={false}>
                {shown.map((c) => (
                  <Row key={c.id} c={c} blind={blind} onOpen={() => setOpen(c.id)} onDecide={decide} onDelete={async () => { await api.removeCandidate(c.id); refresh(); }} />
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      <CandidateDrawer id={open} blind={blind} rank={openRank} onClose={() => setOpen(null)} onDecision={decide} />
    </div>
  );
}

function Stat({ label, value, sub, icon }: { label: string; value: string; sub?: string; icon?: React.ReactNode }) {
  return (
    <div className="glass p-4">
      <div className="flex items-center justify-between text-xs text-zinc-500">
        {label} {icon}
      </div>
      <div className="mt-1 text-3xl font-semibold tracking-tight">{value}</div>
      {sub && <div className="text-xs text-zinc-500">{sub}</div>}
    </div>
  );
}

function Row({
  c, blind, onOpen, onDecide, onDelete,
}: {
  c: Candidate; blind: boolean; onOpen: () => void; onDecide: (id: string, d: string) => void; onDelete: () => void;
}) {
  const tone = scoreTone(c.score);
  const name = blind ? `Candidate #${c.rank ?? "-"}` : c.name;
  const border =
    c.decision === "shortlist" ? "border-emerald-400/40" : c.decision === "reject" ? "border-rose-400/25 opacity-60" : c.decision === "maybe" ? "border-amber-400/40" : "";
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ type: "spring", damping: 26, stiffness: 260 }}
      onClick={c.status === "done" ? onOpen : undefined}
      className={`glass group flex cursor-pointer items-center gap-4 p-4 transition hover:border-violet-400/40 ${border}`}
    >
      <div className="w-7 text-center text-lg font-semibold text-zinc-500">{c.rank ?? "-"}</div>
      <ScoreRing score={c.score} size={60} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-white/8 text-xs font-semibold">{blind ? "?" : initials(c.name)}</span>
          <span className="truncate font-medium">{name}</span>
          {c.status === "done" && <span className={`hidden text-xs font-medium sm:inline ${tone.text}`}>{c.recommendation}</span>}
          {c.decision === "shortlist" && <SkillChip tone="good">Shortlisted</SkillChip>}
        </div>
        {c.status === "processing" && (
          <div className="mt-1.5 flex items-center gap-2 text-sm text-zinc-500">
            <Loader2 size={13} className="animate-spin" /> Reading and scoring...
          </div>
        )}
        {c.status === "error" && <div className="mt-1.5 text-sm text-rose-300">{c.error}</div>}
        {c.status === "done" && (
          <>
            <div className="mt-1 truncate text-sm text-zinc-400">{c.headline}</div>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <SkillChip tone="neutral">{c.matched}/{c.total_reqs} skills matched</SkillChip>
              {(c.years_experience ?? 0) > 0 && <SkillChip>{c.years_experience} yrs</SkillChip>}
              {(c.missing_must ?? []).slice(0, 3).map((m) => (
                <SkillChip key={m} tone="bad">no {m}</SkillChip>
              ))}
              {(c.missing_must?.length ?? 0) > 3 && <span className="text-xs text-zinc-500">+{(c.missing_must?.length ?? 0) - 3} more</span>}
            </div>
          </>
        )}
      </div>
      <div className="hidden items-center gap-1 opacity-0 transition group-hover:opacity-100 md:flex" onClick={(e) => e.stopPropagation()}>
        <button title="Shortlist" onClick={() => onDecide(c.id, c.decision === "shortlist" ? "none" : "shortlist")} className="btn-ghost px-2.5 py-1.5 text-xs">Shortlist</button>
        <button title="Reject" onClick={() => onDecide(c.id, c.decision === "reject" ? "none" : "reject")} className="btn-ghost px-2.5 py-1.5 text-xs">Reject</button>
        <button title="Remove resume" onClick={onDelete} className="rounded-lg p-1.5 text-zinc-500 hover:bg-rose-400/10 hover:text-rose-300"><Trash2 size={14} /></button>
      </div>
    </motion.div>
  );
}
